import sys
import subprocess
from portAndServiceStatusCheck import checkPort
from SMBDiagnostic import smbChecks
from pcapCapture import capPcap
from hyperv import checkHyperVCompatibility
from nutanix import checkNutanixCompatibility
while True:
    print("\n\n1.Check pre-requisites\n2.SMB MV checks\n3.Collect log files\n4.Collect packet capture\n5.exit")
    ip = input("Input:")
    ip1 = int(ip)
    if ip1 == 1:
        checkPort()
        checkHyperVCompatibility('5.2.0')
        checkNutanixCompatibility('7.0.3')
    elif ip1 == 2:
        smbChecks()
    elif ip1 == 3:
        print(subprocess.getoutput('powershell -file get_evtx_csvs.ps1'))
    elif ip1 == 4:
        capPcap()
    elif ip1 == 5:
        break
    else:
        print("Enter a valid input")