import platform
# import cprint
from cprint import cprint

hypervCompatibilityDict = {
    "4.2.0": 2016,
    "5.2.0": 2019,
    "5.2.1": 2019,
    "5.3.0": 2019,
    "6.0": 2019,
    "6.0.1": 2019,
    "7.0": 2019,
}

def checkHyperVCompatibility(cdmVersion):
    
    if cdmVersion in hypervCompatibilityDict:
        systemVersion = platform.release()
        systemVersionInt = int(systemVersion[:4])
        
        # if systemVersionInt < hypervCompatibilityDict[cdmVersion]:
            # cprint('CDM version '+cdmVersion+' does not support Hyper-V '+systemVersion,'red')
        # else:
        cprint.info('Hyper-V version '+systemVersion+' is compatible with CDM '+cdmVersion)
    else:
        cprint.err('Invalid cdm version is supplied')


#checkHyperVCompatibility("5.2.0")######################################

# print(platform.platform())
# print(platform.system())
# print(platform.release())
# print(platform.version())
# print(platform.version().split('.')[2]) 
# print(platform.machine())
# cprint('passed', 'green')